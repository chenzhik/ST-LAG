#!/bin/bash
wget https://civitai.com/api/download/models/189102 -P models/DreamBooth_LoRA/ --content-disposition --no-check-certificate